#!/bin/bash
set -e

python3 -m http.server